Snap-fit w/ peg by vcheung4 on Thingiverse: https://www.thingiverse.com/thing:5179406

Summary:
Smooth snap-fit with a peg to increase the strength connection. Its best to orient the piece on their sides so the print layers help to make the teeth of the snap-fit stronger